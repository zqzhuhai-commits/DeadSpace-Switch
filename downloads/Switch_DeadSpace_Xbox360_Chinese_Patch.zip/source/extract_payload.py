"""Extract the embedded build payload from the supplied Windows EXE without executing it."""
import ctypes,sys
from pathlib import Path
if sys.platform!='win32':raise SystemExit('Run on Windows Python 3')
k=ctypes.WinDLL('kernel32',use_last_error=True)
k.LoadLibraryExW.argtypes=[ctypes.c_wchar_p,ctypes.c_void_p,ctypes.c_uint];k.LoadLibraryExW.restype=ctypes.c_void_p
k.FindResourceW.argtypes=[ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p];k.FindResourceW.restype=ctypes.c_void_p
k.SizeofResource.argtypes=[ctypes.c_void_p,ctypes.c_void_p];k.SizeofResource.restype=ctypes.c_uint32
k.LoadResource.argtypes=[ctypes.c_void_p,ctypes.c_void_p];k.LoadResource.restype=ctypes.c_void_p
k.LockResource.argtypes=[ctypes.c_void_p];k.LockResource.restype=ctypes.c_void_p
k.FreeLibrary.argtypes=[ctypes.c_void_p]
exe=Path(sys.argv[1]).resolve();h=k.LoadLibraryExW(str(exe),None,2)
if not h:raise ctypes.WinError(ctypes.get_last_error())
try:
 r=k.FindResourceW(h,101,10);n=k.SizeofResource(h,r);p=k.LockResource(k.LoadResource(h,r))
 if not p or not n:raise ctypes.WinError(ctypes.get_last_error())
 Path('payload.bin').write_bytes(ctypes.string_at(p,n));print('payload.bin',n)
finally:k.FreeLibrary(h)
