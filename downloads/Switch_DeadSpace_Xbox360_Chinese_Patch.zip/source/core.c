#define _FILE_OFFSET_BITS 64
#include "core.h"
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <windows.h>
#include <bcrypt.h>
#define seek64 _fseeki64
#define tell64 _ftelli64
static int digest(const void*p,size_t n,unsigned char*out){BCRYPT_ALG_HANDLE a=NULL;BCRYPT_HASH_HANDLE h=NULL;int ok=0;if(BCryptOpenAlgorithmProvider(&a,BCRYPT_SHA256_ALGORITHM,NULL,0))goto done;if(BCryptCreateHash(a,&h,NULL,0,NULL,0,0))goto done;if(BCryptHashData(h,(PUCHAR)p,(ULONG)n,0))goto done;if(BCryptFinishHash(h,out,32,0))goto done;ok=1;done:if(h)BCryptDestroyHash(h);if(a)BCryptCloseAlgorithmProvider(a,0);return ok;}
#else
#include <openssl/sha.h>
#define seek64 fseeko
#define tell64 ftello
static int digest(const void*p,size_t n,unsigned char*out){return SHA256(p,n,out)!=NULL;}
#endif
static uint32_t be(const unsigned char*p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static uint32_t le(const unsigned char*p){return ((uint32_t)p[3]<<24)|((uint32_t)p[2]<<16)|((uint32_t)p[1]<<8)|p[0];}
static void putbe(unsigned char*p,uint32_t v){p[0]=v>>24;p[1]=v>>16;p[2]=v>>8;p[3]=v;}
static void putle(unsigned char*p,uint32_t v){p[3]=v>>24;p[2]=v>>16;p[1]=v>>8;p[0]=v;}
static int writeall(FILE*f,const void*b,size_t n){return fwrite(b,1,n,f)==n;}
static int copy_n(FILE*a,FILE*b,uint64_t n){unsigned char buf[1<<20];while(n){size_t k=n>sizeof(buf)?sizeof(buf):(size_t)n;if(fread(buf,1,k,a)!=k||!writeall(b,buf,k))return 0;n-=k;}return 1;}
int patch_viv(FILE *input,FILE*output,const unsigned char*pack,size_t packlen,LogFn log){
 unsigned char h[16],*table=NULL,*old=NULL,*verify=NULL;uint32_t count,hs;int result=0;uint64_t actual,newlen;struct Target{uint32_t oldsize,newsize,index,offset;const unsigned char*sha,*data;}t[3];const unsigned char*p=pack,*end=pack+packlen;
#define FAIL(x) do{if(log)log(x);goto done;}while(0)
 if(packlen<12||memcmp(pack,"DS2PATCH",8)||le(pack+8)!=3)FAIL("补丁数据头无效。");p+=12;
 for(int j=0;j<3;j++){if((size_t)(end-p)<40)FAIL("补丁资源截断。");t[j].oldsize=le(p);t[j].newsize=le(p+4);t[j].sha=p+8;p+=40;if(!t[j].oldsize||!t[j].newsize||t[j].oldsize>64*1024*1024||t[j].newsize>64*1024*1024||(size_t)(end-p)<t[j].newsize)FAIL("补丁资源尺寸无效。");t[j].data=p;p+=t[j].newsize;t[j].index=UINT32_MAX;}
 if(p!=end)FAIL("补丁资源尾部异常。");
 if(seek64(input,0,SEEK_END)||tell64(input)<0)FAIL("无法读取文件长度。");actual=(uint64_t)tell64(input);if(actual>UINT32_MAX)FAIL("当前工具只支持不超过4GiB的单卷BIGH。");
 if(seek64(input,0,SEEK_SET)||fread(h,1,16,input)!=16||memcmp(h,"BIGH",4))FAIL("不是支持的Xbox 360 BIGH/VIV格式。");count=be(h+8);hs=be(h+12);
 if(count<3||count>1000000||hs!=24ULL+count*12ULL||hs>actual||le(h+4)!=actual)FAIL("VIV文件头不匹配或文件不完整。");
 table=malloc((size_t)hs-16);if(!table)FAIL("内存不足。");if(fread(table,1,hs-16,input)!=hs-16)FAIL("读取目录失败。");
 if(log)log("正在校验语言、字体和目录资源的SHA-256……");
 for(uint32_t i=0;i<count;i++){unsigned char*e=table+i*12;uint32_t off=be(e),sz=be(e+4);if((uint64_t)off+sz>actual||(sz&&off<hs))FAIL("VIV条目越界，停止处理。");
  for(int j=0;j<3;j++){if(sz!=t[j].oldsize)continue;old=malloc(sz);if(!old)FAIL("内存不足。");if(seek64(input,off,SEEK_SET)||fread(old,1,sz,input)!=sz)FAIL("读取待替换资源失败。");unsigned char hash[32];if(!digest(old,sz,hash))FAIL("SHA-256校验失败。");free(old);old=NULL;if(memcmp(hash,t[j].sha,32))continue;if(t[j].index!=UINT32_MAX)FAIL("发现重复的目标资源，无法确认版本。");t[j].index=i;}
 }
 for(int j=0;j<3;j++)if(t[j].index==UINT32_MAX)FAIL("文件版本不匹配：未找到完全一致的语言、字体或TOC。未写入补丁。");
 newlen=actual;for(int j=0;j<3;j++){newlen=(newlen+0x7ff)&~(uint64_t)0x7ff;t[j].offset=(uint32_t)newlen;newlen+=t[j].newsize;if(newlen>UINT32_MAX)FAIL("补丁后的文件超过4GiB上限。");}
 if(log)log("资源校验通过。正在复制原文件，原文件将保留……");
 if(seek64(input,0,SEEK_SET)||seek64(output,0,SEEK_SET)||!copy_n(input,output,actual))FAIL("复制失败，请检查磁盘空间。");
 for(int j=0;j<3;j++){uint64_t at=(uint64_t)tell64(output);while(at<t[j].offset){unsigned char zero=0;if(!writeall(output,&zero,1))FAIL("对齐写入失败。");at++;}if(!writeall(output,t[j].data,t[j].newsize))FAIL("写入资源失败。");unsigned char*e=table+t[j].index*12;putbe(e,t[j].offset);putbe(e+4,t[j].newsize);}
 putle(h+4,(uint32_t)newlen);if(seek64(output,0,SEEK_SET)||!writeall(output,h,16)||!writeall(output,table,hs-16)||fflush(output))FAIL("更新目录或保存文件失败。");
 if(log)log("正在回读校验写入后的资源……");
 for(int j=0;j<3;j++){verify=malloc(t[j].newsize);if(!verify)FAIL("内存不足。");if(seek64(output,t[j].offset,SEEK_SET)||fread(verify,1,t[j].newsize,output)!=t[j].newsize||memcmp(verify,t[j].data,t[j].newsize))FAIL("资源回读校验失败。");free(verify);verify=NULL;}
 if(seek64(output,0,SEEK_END)||(uint64_t)tell64(output)!=newlen)FAIL("输出长度校验失败。");if(log)log("汉化副本生成完成。原文件未修改。游戏内显示效果仍需实机确认。");result=1;
 done:free(table);free(old);free(verify);return result;
}
