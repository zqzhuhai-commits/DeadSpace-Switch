#define UNICODE
#define _UNICODE
#include <windows.h>
#include <commdlg.h>
#include <shellapi.h>
#include <wchar.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <io.h>
#include "core.h"
#include "miniz/miniz_tinfl.h"
#define TITLE L"Switch 死亡空间 Xbox360版汉化补丁"
#define LOGMSG (WM_APP+1)
#define DONE (WM_APP+2)
static HWND win,button,logbox;static HFONT font;static int busy=0;
static void append(const wchar_t*s){SendMessageW(logbox,EM_SETSEL,-1,-1);SendMessageW(logbox,EM_REPLACESEL,0,(LPARAM)s);SendMessageW(logbox,EM_REPLACESEL,0,(LPARAM)L"\r\n");}
static void utf8log(const char*s){int n=MultiByteToWideChar(CP_UTF8,0,s,-1,NULL,0);wchar_t*w=malloc(n*sizeof(wchar_t));if(!w)return;MultiByteToWideChar(CP_UTF8,0,s,-1,w,n);PostMessageW(win,LOGMSG,0,(LPARAM)w);}
static void widelog(const wchar_t*s){wchar_t*w=_wcsdup(s);if(w)PostMessageW(win,LOGMSG,0,(LPARAM)w);}
static FILE*openhandle(HANDLE h,int flags,const wchar_t*mode){if(h==INVALID_HANDLE_VALUE)return NULL;int fd=_open_osfhandle((intptr_t)h,flags|_O_BINARY);if(fd<0){CloseHandle(h);return NULL;}FILE*f=_wfdopen(fd,mode);if(!f)_close(fd);return f;}
static DWORD WINAPI run(void*arg){wchar_t*path=arg;FILE*input=NULL,*output=NULL;void*pack=NULL;wchar_t dir[32768],dest[32768],partial[32768];int owned=0,ok=0;dest[0]=partial[0]=0;
 HRSRC res=FindResourceW(NULL,MAKEINTRESOURCEW(101),RT_RCDATA);if(!res){widelog(L"找不到内置补丁资源。");goto done;}DWORD size=SizeofResource(NULL,res);const void*compressed=LockResource(LoadResource(NULL,res));size_t plen=0;pack=tinfl_decompress_mem_to_heap(compressed,size,&plen,TINFL_FLAG_PARSE_ZLIB_HEADER);if(!pack){widelog(L"内置补丁解压失败。");goto done;}
 input=openhandle(CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL),_O_RDONLY,L"rb");if(!input){widelog(L"无法打开原文件；请关闭游戏和其他正在修改此文件的程序。");goto done;}
 if(wcslen(path)>32000){widelog(L"文件路径过长。");goto done;}wcscpy(dir,path);wchar_t*slash=wcsrchr(dir,L'\\');if(!slash){widelog(L"请选择完整文件路径。");goto done;}*slash=0;wcscat(dir,L"\\汉化输出");if(!CreateDirectoryW(dir,NULL)&&GetLastError()!=ERROR_ALREADY_EXISTS){widelog(L"无法创建汉化输出目录。");goto done;}
 swprintf(dest,32768,L"%ls\\bigfile0.viv",dir);swprintf(partial,32768,L"%ls\\bigfile0.viv.partial",dir);
 if(GetFileAttributesW(dest)!=INVALID_FILE_ATTRIBUTES){widelog(L"汉化输出\\bigfile0.viv 已存在。请先移走旧副本，再重新运行。不会覆盖已有文件。");goto done;}
 output=openhandle(CreateFileW(partial,GENERIC_READ|GENERIC_WRITE,0,NULL,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,NULL),_O_RDWR,L"w+b");if(!output){widelog(L"无法创建临时输出。请检查目录权限、剩余空间，或移走上次留下的.partial文件。");goto done;}owned=1;
 if(!patch_viv(input,output,pack,plen,utf8log))goto done;
 if(fflush(output)||!FlushFileBuffers((HANDLE)_get_osfhandle(_fileno(output)))){widelog(L"刷新输出到磁盘失败。");goto done;}if(fclose(output)){output=NULL;widelog(L"关闭输出文件失败。");goto done;}output=NULL;
 if(!MoveFileExW(partial,dest,MOVEFILE_WRITE_THROUGH)){widelog(L"重命名输出失败；未修改原文件。");goto done;}owned=0;ok=1;widelog(L"输出文件：");widelog(dest);widelog(L"保留原始bigfile0.viv作为备份。将汉化副本放回原位置前，请退出游戏。其他分卷保持原样。");
 done:if(output)fclose(output);if(input)fclose(input);if(owned)DeleteFileW(partial);free(pack);free(path);PostMessageW(win,DONE,ok,0);return 0;
}
static LRESULT CALLBACK proc(HWND h,UINT m,WPARAM w,LPARAM l){switch(m){case WM_CREATE:{font=CreateFontW(-16,0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,0,0,CLEARTYPE_QUALITY,0,L"Microsoft YaHei");HWND label=CreateWindowW(L"STATIC",L"死亡空间2 Xbox 360英文资源汉化 · 作者 Xiao Fan\n选择本机bigfile0.viv，校验通过后生成汉化副本，原文件保留。",WS_CHILD|WS_VISIBLE,20,16,720,54,h,0,0,0);SendMessageW(label,WM_SETFONT,(WPARAM)font,1);button=CreateWindowW(L"BUTTON",L"选择 bigfile0.viv 并生成汉化副本",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,20,78,720,38,h,(HMENU)1,0,0);SendMessageW(button,WM_SETFONT,(WPARAM)font,1);logbox=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"",WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_MULTILINE|ES_READONLY|ES_AUTOVSCROLL,20,130,720,310,h,0,0,0);SendMessageW(logbox,WM_SETFONT,(WPARAM)font,1);append(L"包含完整译文、四套扩展字体及对应资源目录更新。");append(L"已完成数据结构校验；游戏内字形、字幕布局和兼容性尚待实机验证。");append(L"工具仅接受与制作资源完全一致的版本，不匹配时会停止。需要原文件大小加约23MB的额外磁盘空间。");return 0;}
 case WM_COMMAND:if(LOWORD(w)==1&&!busy){wchar_t*path=calloc(32768,sizeof(wchar_t));if(!path)break;OPENFILENAMEW o={0};o.lStructSize=sizeof(o);o.hwndOwner=h;o.lpstrFilter=L"VIV游戏资源 (*.viv)\0*.viv\0全部文件\0*.*\0";o.lpstrFile=path;o.nMaxFile=32768;o.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;o.lpstrTitle=L"选择原版bigfile0.viv";if(!GetOpenFileNameW(&o)){free(path);break;}busy=1;EnableWindow(button,FALSE);append(L"开始处理……");HANDLE th=CreateThread(NULL,0,run,path,0,NULL);if(th)CloseHandle(th);else{free(path);busy=0;EnableWindow(button,TRUE);append(L"无法启动处理线程。");}}return 0;
 case LOGMSG:append((wchar_t*)l);free((void*)l);return 0;
 case DONE:busy=0;EnableWindow(button,TRUE);if(w)MessageBoxW(h,L"汉化副本已生成。输出位置见窗口日志。\n游戏内中文显示仍需实机确认。",TITLE,MB_ICONINFORMATION);else MessageBoxW(h,L"未完成。请查看窗口日志；原文件未修改。",TITLE,MB_ICONWARNING);return 0;
 case WM_CLOSE:if(busy){MessageBoxW(h,L"正在处理文件，请等待完成。",TITLE,MB_ICONINFORMATION);return 0;}DestroyWindow(h);return 0;
 case WM_DESTROY:DeleteObject(font);PostQuitMessage(0);return 0;}return DefWindowProcW(h,m,w,l);}
int WINAPI wWinMain(HINSTANCE inst,HINSTANCE prev,PWSTR cmd,int show){WNDCLASSW c={0};c.lpfnWndProc=proc;c.hInstance=inst;c.lpszClassName=L"DS2ChinesePatcher";c.hCursor=LoadCursor(NULL,IDC_ARROW);c.hbrBackground=(HBRUSH)(COLOR_WINDOW+1);if(!RegisterClassW(&c))return 1;win=CreateWindowW(c.lpszClassName,TITLE,WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX,CW_USEDEFAULT,CW_USEDEFAULT,780,500,NULL,NULL,inst,NULL);ShowWindow(win,show);MSG msg;while(GetMessageW(&msg,NULL,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}return 0;}
