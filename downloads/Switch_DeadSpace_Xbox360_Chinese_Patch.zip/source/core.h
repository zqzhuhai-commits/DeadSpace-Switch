#ifndef CORE_H
#define CORE_H
#include <stdio.h>
#include <stdint.h>
typedef void (*LogFn)(const char*);
int patch_viv(FILE *input, FILE *output, const unsigned char *pack, size_t packlen, LogFn log);
#endif
