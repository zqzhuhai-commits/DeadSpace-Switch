#include "core.h"
#include "miniz/miniz_tinfl.h"
#include <stdlib.h>
int main(int n,char**v){if(n!=4)return 2;FILE*f=fopen(v[1],"rb");if(!f)return 3;fseek(f,0,2);long sz=ftell(f);rewind(f);void*c=malloc(sz);if(fread(c,1,sz,f)!=sz)return 4;fclose(f);size_t len=0;void*p=tinfl_decompress_mem_to_heap(c,sz,&len,TINFL_FLAG_PARSE_ZLIB_HEADER);if(!p)return 5;FILE*i=fopen(v[2],"rb"),*o=fopen(v[3],"w+b");if(!i||!o)return 6;int r=patch_viv(i,o,p,len,(LogFn)puts);fclose(i);fclose(o);free(c);free(p);return r?0:1;}
