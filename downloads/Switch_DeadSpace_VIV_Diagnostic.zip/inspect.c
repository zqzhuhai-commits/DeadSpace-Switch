#define _FILE_OFFSET_BITS 64
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#ifndef UNICODE
#define UNICODE
#endif
#define _UNICODE
#include <windows.h>
#include <commdlg.h>
#include <bcrypt.h>
#define SK _fseeki64
#define TL _ftelli64
static int hash(const unsigned char*p,size_t n,unsigned char*out){BCRYPT_ALG_HANDLE a=0;BCRYPT_HASH_HANDLE h=0;int ok=0;if(BCryptOpenAlgorithmProvider(&a,BCRYPT_SHA256_ALGORITHM,0,0))goto done;if(BCryptCreateHash(a,&h,0,0,0,0,0))goto done;if(BCryptHashData(h,(PUCHAR)p,(ULONG)n,0)||BCryptFinishHash(h,out,32,0))goto done;ok=1;done:if(h)BCryptDestroyHash(h);if(a)BCryptCloseAlgorithmProvider(a,0);return ok;}
#else
#include <openssl/sha.h>
#define SK fseeko
#define TL ftello
static int hash(const unsigned char*p,size_t n,unsigned char*out){return SHA256(p,n,out)!=NULL;}
#endif
static uint32_t be(const unsigned char*p){return (uint32_t)p[0]<<24|(uint32_t)p[1]<<16|(uint32_t)p[2]<<8|p[3];}
static uint32_t le(const unsigned char*p){return (uint32_t)p[3]<<24|(uint32_t)p[2]<<16|(uint32_t)p[1]<<8|p[0];}
static void hex(FILE*r,const unsigned char*p,size_t n){for(size_t i=0;i<n;i++)fprintf(r,"%02x",p[i]);}
static int inspect(FILE*f,FILE*r){
 unsigned char h[16],e[12];uint64_t length,previous=0;unsigned counts[4]={0};
 fprintf(r,"VIV read-only diagnostic v1\nNo game data is modified. No file paths or account information recorded.\n");
 if(SK(f,0,SEEK_END)||TL(f)<0){fprintf(r,"ERROR: length\n");return 0;}length=(uint64_t)TL(f);fprintf(r,"actual_bytes=%llu\n",(unsigned long long)length);
 if(SK(f,0,SEEK_SET)||fread(h,1,16,f)!=16){fprintf(r,"ERROR: short header\n");return 0;}
 fprintf(r,"header_hex=");hex(r,h,16);fprintf(r,"\n");
 if(memcmp(h,"BIGH",4)){fprintf(r,"ERROR: not BIGH\n");return 0;}
 uint32_t count=be(h+8),hs=be(h+12);fprintf(r,"declared_bytes_le=%u\nentry_count=%u\nheader_bytes=%u\n",le(h+4),count,hs);
 if(count>1000000||16ULL+12ULL*count>length){fprintf(r,"ERROR: directory bounds\n");return 0;}
 fprintf(r,"index,name_hash,offset,size,offset_mod_128K\n");
 for(uint32_t i=0;i<count;i++){
  if(SK(f,16ULL+12ULL*i,SEEK_SET)||fread(e,1,12,f)!=12){fprintf(r,"ERROR: entry read\n");return 0;}
  uint32_t off=be(e),size=be(e+4),name=be(e+8);
  fprintf(r,"%u,%08X,%u,%u,%u\n",i,name,off,size,off%131072);
  if(off%131072==0)counts[0]++;
  if(off%2048==0)counts[1]++;
  if(i&&off<previous)counts[2]++;
  if((uint64_t)off+size>length)counts[3]++;
  previous=off;
  if(size==262144||size==524288||size==2048||size==393216||size==22806528){
   if((uint64_t)off+size>length){fprintf(r,"ERROR: candidate out of bounds\n");continue;}
   unsigned char *b=malloc(size),sha[32];if(!b){fprintf(r,"ERROR: memory\n");return 0;}
   if(SK(f,off,SEEK_SET)||fread(b,1,size,f)!=size){free(b);fprintf(r,"ERROR: candidate read\n");return 0;}
   fprintf(r,"candidate index=%u sha256=",i);if(hash(b,size,sha))hex(r,sha,32);else fprintf(r,"HASH_ERROR");fprintf(r," first128=");hex(r,b,size<128?size:128);fprintf(r,"\n");free(b);
  }
 }
 fprintf(r,"aligned_128K=%u\naligned_2048=%u\nbackwards_offsets=%u\nout_of_bounds=%u\n",counts[0],counts[1],counts[2],counts[3]);
 if(counts[3]||le(h+4)!=length||hs>length){fprintf(r,"ERROR: inconsistent file bounds or declared size\n");return 0;}
 return 1;
}
#ifdef _WIN32
int WINAPI wWinMain(HINSTANCE a,HINSTANCE b,PWSTR c,int d){
 wchar_t src[32768]={0},dst[32768]={0};OPENFILENAMEW o={0};o.lStructSize=sizeof(o);o.lpstrFilter=L"VIV (*.viv)\0*.viv\0All files\0*.*\0";o.lpstrFile=src;o.nMaxFile=32768;o.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;o.lpstrTitle=L"选择原版或黑屏的 bigfile0.viv（只读检查）";
 if(!GetOpenFileNameW(&o))return 0;
 FILE*f=_wfopen(src,L"rb");if(!f){MessageBoxW(0,L"无法读取文件。请退出游戏后重试。",L"VIV 只读诊断",MB_ICONERROR);return 1;}
 wcscpy(dst,L"VIV_diagnostic.txt");o.lpstrFile=dst;o.lpstrFilter=L"Text (*.txt)\0*.txt\0";o.lpstrDefExt=L"txt";o.Flags=OFN_PATHMUSTEXIST|OFN_OVERWRITEPROMPT|OFN_NOCHANGEDIR;o.lpstrTitle=L"保存诊断报告（请区分原版与黑屏版）";
 if(!GetSaveFileNameW(&o)){fclose(f);return 0;}
 if(!_wcsicmp(src,dst)){fclose(f);MessageBoxW(0,L"报告不能覆盖输入文件。",L"VIV 只读诊断",MB_ICONERROR);return 1;}
 FILE*r=_wfopen(dst,L"wb");if(!r){fclose(f);MessageBoxW(0,L"无法保存报告。",L"VIV 只读诊断",MB_ICONERROR);return 1;}
 int ok=inspect(f,r);fclose(f);if(fclose(r))ok=0;
 MessageBoxW(0,ok?L"诊断报告已保存。请把原版和黑屏版的报告一起发回。\nVIV 文件未作修改。":L"检查未完成，已保存错误信息。请发回报告。\nVIV 文件未作修改。",L"VIV 只读诊断",ok?MB_ICONINFORMATION:MB_ICONWARNING);return ok?0:1;
}
#else
int main(int c,char**v){if(c!=3)return 2;FILE*f=fopen(v[1],"rb");if(!f)return 2;FILE*r=fopen(v[2],"wb");if(!r){fclose(f);return 2;}int ok=inspect(f,r);fclose(f);if(fclose(r))ok=0;return ok?0:1;}
#endif
