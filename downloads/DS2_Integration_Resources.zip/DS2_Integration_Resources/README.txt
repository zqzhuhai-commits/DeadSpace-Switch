死亡空间2 Xbox 360 中文资源集成包

本包为封装研究的实际输出，不是可直接覆盖的完整游戏补丁。

已完成
1. 读取8CA715C3中的单一英文LH2资源头，其声明长度351220字节，与翻译工程原文一致。
2. 原容器未压缩尾段中16087字节与原文文件尾部逐字节一致。压缩前段未做完整解压比对。
3. 以原资源头为模板，使用SDAT未压缩块封装中文LH2，生成393216字节的8CA715C3_zh_raw.ols3。
4. 对新容器重新解析，并逐字节验证其恢复出的LH2等于已完成译文的zh_CN_final.lh2。
5. 解析text_assets_global.str，共518个资源；找到4套文字字体以及1套按钮字体。
6. 4套文字字体的字符表均无CJK字形。现译文需要1964个去重汉字，均需新增。

文件
8CA715C3_zh_raw.ols3：未压缩中文语言容器，供后续VIV集成；尚未验证游戏是否接受。
integration_audit.json：原始资源检查结果。
tools/ols3_resource.py：只支持此大端ols3布局；支持资源目录检查与单LH2未压缩封装。
tools/lh2_text.py：LH2解析工具。

检查命令
python tools/ols3_resource.py inspect 8CA715C3_zh_raw.ols3

未完成
中文字形图集和字体索引扩展、Xbox 360纹理布局与编码、外层VIV目录及资源大小更新、实机启动及中文布局验证。
原语言容器262144字节，新容器393216字节，不能原位置强塞或仅修改文件名覆盖；否则可能覆盖后续资源或令VIV索引失效。

需要补充
与上述资源相同版本的完整bigfile0.viv。若存在bigfile1.viv等分卷，请同时保留并提供。
只需游戏数据资源，不需要主机密钥或账号信息。
收到完整VIV后，可以继续核对外层索引、文件条目与分配空间；中文字库仍需另行完成并验证。

格式参考
https://github.com/gibbed/Gibbed.Visceral/blob/master/projects/Gibbed.Visceral.FileFormats/StreamSetFile.cs
https://github.com/gibbed/Gibbed.Visceral/blob/master/projects/Gibbed.Visceral.FileFormats/StreamSet/FileInfo.cs
本包Python实现为独立实现，不包含上述C#代码。
