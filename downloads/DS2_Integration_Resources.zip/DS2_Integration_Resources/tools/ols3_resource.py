"""Inspect big-endian ols3/SHOC streams and build a single raw LH2 stream.

Layout reference: gibbed/Gibbed.Visceral StreamSetFile.cs and
StreamSet/FileInfo.cs. This implementation is independent Python code.
LZXD decompression and VIV indexing are deliberately not implemented.
"""
from pathlib import Path
import argparse, struct, json

def scan(data):
    if data[:8] != b'ols3\x00\x00\x00\x0c':
        raise ValueError('Expected big-endian ols3')
    pos = 12
    blocks = []
    while pos < len(data):
        if not any(data[pos:]):
            break
        if pos + 8 > len(data):
            raise ValueError('Truncated block header')
        tag, size = data[pos:pos+4], int.from_bytes(data[pos+4:pos+8], 'big')
        if size < 8 or pos + size > len(data):
            raise ValueError('Invalid block size at ' + hex(pos))
        if tag not in (b'SHOC', b'FILL'):
            raise ValueError('Unknown block tag at ' + hex(pos))
        if tag == b'SHOC' and size < 12:
            raise ValueError('Short SHOC block')
        blocks.append({'offset': pos, 'size': size, 'tag': tag.decode(),
                       'type': data[pos+8:pos+12].decode('ascii') if tag == b'SHOC' else None})
        pos += size
    return blocks

def resources(data):
    result = []
    current = None
    for b in scan(data):
        if b['tag'] != 'SHOC':
            continue
        pos = b['offset']
        if b['type'] == 'SHDR':
            strings = data[pos+44:pos+b['size']].split(b'\0')
            if len(strings) < 3:
                raise ValueError('Incomplete SHDR names')
            current = {'name': strings[1].decode('utf8'), 'type': strings[2].decode('ascii'),
                       'total_size': int.from_bytes(data[pos+40:pos+44], 'big'),
                       'header_offset': pos, 'header_size': b['size'], 'parts': []}
            result.append(current)
        elif b['type'] in ('SDAT', 'LZXD'):
            if current is None:
                raise ValueError('Data before resource header')
            current['parts'].append(b)
        else:
            raise ValueError('Unsupported content type: ' + b['type'])
    return result

def read_raw(data, resource):
    if any(p['type'] != 'SDAT' for p in resource['parts']):
        raise ValueError('Resource is compressed; no decompression implemented')
    out = b''.join(data[p['offset']+12:p['offset']+p['size']] for p in resource['parts'])
    if len(out) < resource['total_size']:
        raise ValueError('Resource data incomplete')
    return out[:resource['total_size']]

def build_lh2(template, payload):
    from lh2_text import parse
    parse(payload)
    entries = resources(template)
    if len(entries) != 1 or entries[0]['type'] != 'LH2':
        raise ValueError('Template must contain exactly one LH2 resource')
    item = entries[0]
    if item['header_offset'] != 12:
        raise ValueError('Unexpected template layout')
    out = bytearray(template[:12+item['header_size']])
    struct.pack_into('>I', out, 12+40, len(payload))
    offset = 0
    while offset < len(payload):
        room = 0x20000 - (len(out) % 0x20000)
        if room < 16:
            out += b'FILL' + struct.pack('>I', room) + bytes(room-8)
            continue
        count = min(len(payload)-offset, room-12)
        chunk = payload[offset:offset+count]
        pad = (-len(chunk)) % 4
        out += b'SHOC' + struct.pack('>I', len(chunk)+pad+12) + b'SDAT' + chunk + bytes(pad)
        offset += count
    out += bytes((-len(out)) % 0x20000)
    built = bytes(out)
    recovered = read_raw(built, resources(built)[0])
    if recovered != payload:
        raise ValueError('Output resource roundtrip mismatch')
    return built

if __name__ == '__main__':
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument('mode', choices=['inspect', 'build-lh2'])
    a.add_argument('input')
    a.add_argument('payload', nargs='?')
    a.add_argument('output', nargs='?')
    args = a.parse_args()
    data = Path(args.input).read_bytes()
    if args.mode == 'inspect':
        print(json.dumps(resources(data), ensure_ascii=False, indent=2))
    else:
        if not args.payload or not args.output:
            a.error('build-lh2 requires template, LH2 payload and output')
        if Path(args.output).resolve() in (Path(args.input).resolve(), Path(args.payload).resolve()):
            a.error('Output must be a separate file')
        built = build_lh2(data, Path(args.payload).read_bytes())
        Path(args.output).write_bytes(built)
        print('OK: structure and LH2 payload roundtrip verified;', len(built), 'bytes')
