Runtime only. No game data is included. Import your own supported Xperia Play 1.1.33 data with switch/tools/prepare_data.py from the matching source. Use full application mode. Switch hardware/emulator and full campaign remain unverified.
Source and build instructions: https://github.com/zqzhuhai-commits/DeadSpace-Switch/tree/9c2897c2bb3953931404f5d937f3d293fa687da5
